// ============ REPORTS PAGE JAVASCRIPT ============

// Configuration
const OFFLINE_MS = 60000;
const STALE_MS = 120000; // 2 minutes for stale warning
const MAX_SPEED_SAMPLES = 200;

// Global state
const devices = {};
const exercisesCache = {};
const routesCache = {};
const completedCheckpoints = new Set();

// ============ FIREBASE CONFIG ============
const firebaseConfig = {
  apiKey: "AIzaSyBqgUJGP2orVBT-jLzcGtkG_d_JK0qNNh8",
  authDomain: "tracker-6c988.firebaseapp.com",
  databaseURL: "https://tracker-6c988-default-rtdb.firebaseio.com",
  projectId: "tracker-6c988",
  storageBucket: "tracker-6c988.appspot.com",
  messagingSenderId: "339384342086",
  appId: "1:339384342086:web:89e763dbc43a85d3ab5c47",
  measurementId: "G-WEFZ7RXYE1"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// ============ UTILITY FUNCTIONS ============
function toNumber(value) {
  const n = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(n) ? n : null;
}

function formatAge(ms) {
  if (ms < 1000) return 'Just now';
  const s = Math.floor(ms / 1000);
  if (s < 60) return s + 's ago';
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m + 'm ' + r + 's ago';
}

function formatMsToClock(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
}

// Calculate distance between two points in kilometers (Haversine)
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function distanceMeters(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toRad = function(v) { return v * Math.PI / 180; };
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function computeDistanceFromPoints(points) {
  if (!points || points.length < 2) return 0;
  var total = 0;
  for (var i = 1; i < points.length; i++) {
    var a = points[i - 1];
    var b = points[i];
    total += calculateDistance(a.lat, a.lng, b.lat, b.lng);
  }
  return total;
}

// Battery functions
function normalizeBatteryVoltage(voltageRaw) {
  if (voltageRaw === null || voltageRaw === undefined) return null;
  const v = toNumber(voltageRaw);
  if (v === null) return null;
  if (v > 20 && v < 10000) return v / 1000;
  return v;
}

function mapBatteryPercentFromVoltage(voltage) {
  const v = toNumber(voltage);
  if (v === null) return null;
  var points = [[4.20, 100], [4.00, 80], [3.85, 60], [3.70, 40], [3.30, 10], [3.00, 0]];
  if (v >= points[0][0]) return points[0][1];
  if (v <= points[points.length - 1][0]) return points[points.length - 1][1];
  for (var i = 0; i < points.length - 1; i++) {
    var vHigh = points[i][0], pHigh = points[i][1];
    var vLow = points[i + 1][0], pLow = points[i + 1][1];
    if (v <= vHigh && v >= vLow) {
      var ratio = (v - vLow) / (vHigh - vLow);
      return Math.round(pLow + ratio * (pHigh - pLow));
    }
  }
  return null;
}

function getBatteryFromDeviceData(data) {
  var voltage = normalizeBatteryVoltage(
    data.bat || data.batteryVoltage || data.battery_voltage ||
    data.voltage || data.vbat || data.vbatt
  );
  var pct = mapBatteryPercentFromVoltage(voltage);
  return { voltage: voltage, pct: pct };
}

function getBatteryClassName(pct) {
  if (pct === null) return '';
  if (pct < 20) return 'battery-low';
  if (pct < 50) return 'battery-medium';
  return 'battery-high';
}

// Activity status
function getActivityStatus(lastSeen) {
  var now = Date.now();
  var age = now - Number(lastSeen);
  var active = age <= OFFLINE_MS;
  return {
    active: active,
    moving: active,
    label: active ? 'Active' : 'Inactive',
    movingLabel: active ? 'Moving' : 'Stationary'
  };
}

// Signal quality (HDOP)
function getFixStatus(hdop) {
  if (hdop === null || hdop === undefined || isNaN(Number(hdop))) {
    return { label: 'Unknown', cls: 'fix-unknown' };
  }
  var v = Number(hdop);
  if (v <= 1.5) return { label: 'Good', cls: 'fix-good' };
  if (v <= 3) return { label: 'Degraded', cls: 'fix-warn' };
  return { label: 'Poor', cls: 'fix-bad' };
}

function parseLastUpdateMs(raw) {
  if (raw === null || raw === undefined || raw === '') return null;
  if (typeof raw === 'number' && isFinite(raw)) {
    return raw > 1e12 ? raw : raw * 1000;
  }
  var maybe = Number(raw);
  if (isFinite(maybe) && raw !== '') {
    return maybe > 1e12 ? maybe : maybe * 1000;
  }
  var parsed = Date.parse(String(raw));
  return isFinite(parsed) ? parsed : null;
}

function coerceCoord(raw) {
  if (!raw) return null;
  var lat = toNumber(raw.lat);
  var lng = toNumber(raw.lng);
  if (lat === null || lng === null) return null;
  var t = toNumber(raw.t);
  var spd = toNumber(raw.spd || raw.speed);
  var hdop = toNumber(raw.hdop);
  var alt = toNumber(raw.alt);
  var batteryVoltage = normalizeBatteryVoltage(
    raw.bat || raw.batteryVoltage || raw.battery_voltage || raw.voltage || raw.vbat || raw.vbatt
  );
  var batteryPercent = mapBatteryPercentFromVoltage(batteryVoltage);
  return { lat: lat, lng: lng, t: t, spd: spd, speed: spd, hdop: hdop, alt: alt, batteryPercent: batteryPercent, batteryVoltage: batteryVoltage, timestamp: raw.timestamp };
}

function coordSortValue(coord, fallbackIndex) {
  var t = toNumber(coord.t);
  if (t !== null) return t;
  if (coord.timestamp) {
    var ts = Date.parse(coord.timestamp);
    if (!isNaN(ts)) return ts;
  }
  return fallbackIndex;
}

// ============ DATA FETCHING ============
var historiesCache = {};
var HISTORY_TTL = 30000;

async function fetchHistory(deviceName) {
  var now = Date.now();
  var cached = historiesCache[deviceName];
  if (cached && (now - cached.ts) < HISTORY_TTL) return cached.points;
  
  try {
    var devSnap = await db.ref('devices/' + deviceName).once('value');
    var devVal = devSnap.val() || {};
    
    var points = [];
    var flat = coerceCoord(devVal);
    if (flat) {
      points = [{ lat: flat.lat, lng: flat.lng, time: flat.t || now }];
    } else {
      var children = Object.values(devVal)
        .map(function(p, idx) {
          var c = coerceCoord(p);
          return c ? { lat: c.lat, lng: c.lng, time: c.t, _sort: coordSortValue(c, idx) } : null;
        })
        .filter(Boolean)
        .sort(function(a, b) { return a._sort - b._sort; });
      points = children.map(function(p) { return { lat: p.lat, lng: p.lng, time: p.time }; });
    }
    
    historiesCache[deviceName] = { ts: now, points: points };
    return points;
  } catch (e) {
    console.error('fetchHistory error', e);
    historiesCache[deviceName] = { ts: now, points: [] };
    return [];
  }
}

// ============ EXERCISE FUNCTIONS ============
var EXERCISE_STORAGE_KEY = 'gako_exercises_v1';

function getExerciseStore() {
  var cached = Object.values(exercisesCache);
  if (cached.length > 0) return cached;
  try {
    var raw = localStorage.getItem(EXERCISE_STORAGE_KEY);
    var parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}

function getSelectedExercise() {
  var select = document.getElementById('exerciseSelect');
  if (!select || !select.value) return null;
  return getExerciseStore().find(function(x) { return x.id === select.value; }) || null;
}

function autoSelectExercise() {
  var select = document.getElementById('exerciseSelect');
  if (!select) return;
  var list = getExerciseStore();
  if (!list || list.length === 0) return;
  // Prefer a running exercise, otherwise first item
  var running = list.find(function(x){ return x.running; });
  var target = running || list[0];
  if (select.value !== target.id) {
    select.value = target.id;
  }
}

function getCurrentExerciseElapsedMs(exercise) {
  if (!exercise) return 0;
  var base = Number(exercise.elapsedBeforeMs || 0);
  if (!exercise.running || !exercise.startedAtMs) return base;
  return base + (Date.now() - Number(exercise.startedAtMs));
}

function parseAllowedTimeToMs(value) {
  if (!value) return 0;
  var parts = String(value).split(':').map(Number);
  if (parts.some(function(v) { return isNaN(v); })) return 0;
  var hh = parts[0] || 0, mm = parts[1] || 0, ss = parts[2] || 0;
  return (((hh * 60) + mm) * 60 + ss) * 1000;
}

// ============ RENDER FUNCTIONS ============

// Section 1: Exercise Summary
function renderExerciseSummary() {
  var exercise = getSelectedExercise() || (autoSelectExercise(), getSelectedExercise());
  
  var exerciseName = exercise ? exercise.name : 'Not Set';
  var exerciseDate = exercise ? (exercise.date || (exercise.startedAtMs ? new Date(Number(exercise.startedAtMs)).toLocaleDateString() : '--')) : '--';
  var startTime = exercise ? (exercise.startTime || (exercise.startedAtMs ? new Date(Number(exercise.startedAtMs)).toLocaleTimeString() : '--')) : '--';
  var endTime = exercise && exercise.running ? 'In Progress' : (exercise && (exercise.endTime || exercise.endedAtMs)) ? (exercise.endTime || new Date(Number(exercise.endedAtMs)).toLocaleTimeString()) : '--';
  
  var deviceCount = Object.keys(devices).length;
  var nowTime = Date.now();
  var activeDevices = Object.values(devices).filter(function(d) { return (nowTime - d.lastSeen) <= OFFLINE_MS; }).length;
  var inactiveDevices = deviceCount - activeDevices;
  
  document.getElementById('summaryExerciseName').textContent = exerciseName;
  document.getElementById('summaryDate').textContent = exerciseDate;
  document.getElementById('summaryStartTime').textContent = startTime;
  document.getElementById('summaryEndTime').textContent = endTime;
  document.getElementById('summaryTotalDevices').textContent = deviceCount;
  document.getElementById('summaryActiveDevices').textContent = activeDevices;
  document.getElementById('summaryInactiveDevices').textContent = inactiveDevices;
}

// Section 2: Device Performance Table
function renderDevicePerformanceTable() {
  var tbody = document.getElementById('devicePerformanceBody');
  var deviceEntries = Object.entries(devices);
  
  if (deviceEntries.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" class="no-data">No device data available</td></tr>';
    return;
  }
  
  var html = '';
  
  for (var i = 0; i < deviceEntries.length; i++) {
    var name = deviceEntries[i][0];
    var dev = deviceEntries[i][1];
    var lastUpdateMs = parseLastUpdateMs(dev.data ? dev.data.lastUpdateTime : null) || dev.lastSeen;
    var age = Date.now() - lastUpdateMs;
    var activity = getActivityStatus(dev.lastSeen);
    var batt = getBatteryFromDeviceData(dev.data || {});
    var battPct = batt.pct === null ? 'N/A' : Math.round(batt.pct) + '%';
    var battClass = getBatteryClassName(batt.pct);
    
    var distanceKm = computeDistanceFromPoints(dev.points || []);
    
    // Get checkpoint info
    var routeNode = routesCache[name];
    var checkpoints = routeNode ? routeNode.checkpoints : {};
    var totalCheckpoints = Object.keys(checkpoints).length;
    var completedCount = 0;
    for (var cpId in checkpoints) {
      if (completedCheckpoints.has(name + '_' + cpId)) completedCount++;
    }
    
    var avgSpeed = dev.avgSpeed || 0;
    var maxSpeed = dev.maxSpeed || 0;
    
    html += '<tr>';
    html += '<td><strong>' + name + '</strong></td>';
    html += '<td><span class="status-badge ' + (activity.active ? 'status-active' : 'status-inactive') + '">' + activity.label + '</span></td>';
    html += '<td>' + distanceKm.toFixed(2) + ' km</td>';
    html += '<td>' + Number(avgSpeed).toFixed(1) + ' km/h</td>';
    html += '<td>' + Number(maxSpeed).toFixed(1) + ' km/h</td>';
    html += '<td class="' + battClass + '">' + battPct + '</td>';
    html += '<td>' + completedCount + '/' + totalCheckpoints + '</td>';
    html += '<td>' + formatAge(age) + '</td>';
    html += '</tr>';
  }
  
  tbody.innerHTML = html;
}

// Section 3: Device Activity Monitoring
function renderDeviceActivity() {
  var container = document.getElementById('activityContainer');
  var deviceEntries = Object.entries(devices);
  
  if (deviceEntries.length === 0) {
    container.innerHTML = '<div class="no-data"><div class="no-data-icon">📡</div><div class="no-data-text">No devices available</div></div>';
    return;
  }
  
  var now = Date.now();
  var html = '';
  
  for (var i = 0; i < deviceEntries.length; i++) {
    var name = deviceEntries[i][0];
    var dev = deviceEntries[i][1];
    var lastUpdateMs = parseLastUpdateMs(dev.data ? dev.data.lastUpdateTime : null) || dev.lastSeen;
    var age = now - lastUpdateMs;
    var isStale = age > STALE_MS;
    var activity = getActivityStatus(dev.lastSeen);
    var fix = getFixStatus(dev.data ? dev.data.hdop : null);
    
    html += '<div class="activity-card' + (isStale ? ' activity-stale' : '') + '">';
    html += '<div class="activity-header">';
    html += '<span class="activity-device">' + name + '</span>';
    html += '<span class="activity-status status-badge ' + (activity.moving ? 'status-moving' : 'status-stationary') + '">' + activity.movingLabel + '</span>';
    html += '</div>';
    html += '<div class="activity-stats">';
    html += '<div class="activity-stat"><div class="activity-stat-label">Last Update</div><div class="activity-stat-value">' + formatAge(age) + '</div></div>';
    html += '<div class="activity-stat"><div class="activity-stat-label">Signal (HDOP)</div><div class="activity-stat-value ' + fix.cls + '">' + (dev.data && dev.data.hdop ? dev.data.hdop : 'N/A') + ' (' + fix.label + ')</div></div>';
    html += '</div></div>';
  }
  
  container.innerHTML = html;
}

// Section 4: Exercise Timeline
function renderExerciseTimeline() {
  var container = document.getElementById('timelineContainer');
  var deviceEntries = Object.entries(devices);
  
  if (deviceEntries.length === 0) {
    container.innerHTML = '<div class="no-data"><div class="no-data-icon">⏱️</div><div class="no-data-text">No timeline data available</div></div>';
    return;
  }
  
  var html = '';
  
  for (var i = 0; i < deviceEntries.length; i++) {
    var name = deviceEntries[i][0];
    var dev = deviceEntries[i][1];
    var routeNode = routesCache[name];
    var checkpoints = routeNode ? routeNode.checkpoints : {};
    var checkpointList = Object.entries(checkpoints).map(function(pair, idx) {
      var cpId = pair[0];
      var cp = pair[1] || {};
      var timeMs = parseLastUpdateMs(cp.completedAt || cp.verifiedAt || cp.t || cp.timestamp || cp.time);
      return { id: cpId, label: cp.label || ('Checkpoint ' + (idx + 1)), timeMs: timeMs };
    }).filter(function(c){ return c.timeMs !== null; }).sort(function(a,b){ return a.timeMs - b.timeMs; });
    
    var exercise = getSelectedExercise();
    var startTime = exercise && exercise.startTime ? exercise.startTime : (checkpointList[0] ? new Date(checkpointList[0].timeMs).toLocaleTimeString() : 'Unknown');
    
    html += '<div class="timeline-device">';
    html += '<div class="timeline-device-name">' + name + '</div>';
    html += '<div class="timeline-events">';
    html += '<div class="timeline-event"><span class="timeline-event-time">' + startTime + '</span><span class="timeline-event-label">Start</span></div>';
    
    for (var j = 0; j < checkpointList.length; j++) {
      var cpEvent = checkpointList[j];
      var timeStr = new Date(cpEvent.timeMs).toLocaleTimeString();
      html += '<div class="timeline-event"><span class="timeline-event-time">' + timeStr + '</span><span class="timeline-event-label timeline-event-checkpoint">' + cpEvent.label + '</span></div>';
    }
    
    if (checkpointList.length > 0) {
      var lastTime = new Date(checkpointList[checkpointList.length - 1].timeMs).toLocaleTimeString();
      html += '<div class="timeline-event"><span class="timeline-event-time">' + lastTime + '</span><span class="timeline-event-label timeline-event-finish">Finish</span></div>';
    }
    
    html += '</div></div>';
  }
  
  container.innerHTML = html;
}

// Section 5: Performance Metrics Dashboard
function renderPerformanceMetrics() {
  var now = Date.now();
  var deviceEntries = Object.entries(devices);
  
  // Total distance
  var totalDistance = 0;
  for (var i = 0; i < deviceEntries.length; i++) {
    var dev = deviceEntries[i][1];
    totalDistance += computeDistanceFromPoints(dev.points || []);
  }
  
  // Average speed
  var totalSpeed = 0;
  var speedCount = 0;
  for (var i = 0; i < deviceEntries.length; i++) {
    var dev = deviceEntries[i][1];
    if (dev.avgSpeed !== undefined) {
      totalSpeed += dev.avgSpeed;
      speedCount++;
    }
  }
  var avgSpeed = speedCount > 0 ? totalSpeed / speedCount : 0;
  
  // Total checkpoints
  var totalCheckpoints = 0;
  var totalCompleted = 0;
  for (var deviceId in routesCache) {
    var cps = routesCache[deviceId] ? routesCache[deviceId].checkpoints : {};
    totalCheckpoints += Object.keys(cps).length;
    for (var cpId in cps) {
      if (completedCheckpoints.has(deviceId + '_' + cpId)) totalCompleted++;
    }
  }
  
  // Devices moving
  var movingDevices = 0;
  for (var i = 0; i < deviceEntries.length; i++) {
    var dev = deviceEntries[i][1];
    if ((now - dev.lastSeen) <= OFFLINE_MS) movingDevices++;
  }
  
  // Low battery devices
  var lowBatteryCount = 0;
  for (var i = 0; i < deviceEntries.length; i++) {
    var dev = deviceEntries[i][1];
    var batt = getBatteryFromDeviceData(dev.data || {});
    if (batt.pct !== null && batt.pct < 20) lowBatteryCount++;
  }
  
  document.getElementById('metricTotalDistance').textContent = totalDistance.toFixed(2) + ' km';
  document.getElementById('metricAvgSpeed').textContent = avgSpeed.toFixed(1) + ' km/h';
  document.getElementById('metricCheckpoints').textContent = totalCompleted + '/' + totalCheckpoints;
  document.getElementById('metricMoving').textContent = movingDevices;
  document.getElementById('metricLowBattery').textContent = lowBatteryCount;
}

// Section 6: Charts
var speedChart, distanceChart, batteryChart;

function initCharts() {
  var chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        labels: { color: '#e6f7ff', font: { family: 'Exo 2' } }
      }
    },
    scales: {
      x: {
        ticks: { color: '#7a8ca0' },
        grid: { color: 'rgba(0, 230, 255, 0.1)' }
      },
      y: {
        ticks: { color: '#7a8ca0' },
        grid: { color: 'rgba(0, 230, 255, 0.1)' }
      }
    }
  };
  
  // Speed vs Time Chart
  var speedCtx = document.getElementById('speedChart').getContext('2d');
  speedChart = new Chart(speedCtx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: 'Speed (km/h)',
        data: [],
        borderColor: '#00e6ff',
        backgroundColor: 'rgba(0, 230, 255, 0.1)',
        fill: true,
        tension: 0.4
      }]
    },
    options: chartOptions
  });
  
  // Distance vs Time Chart
  var distanceCtx = document.getElementById('distanceChart').getContext('2d');
  distanceChart = new Chart(distanceCtx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: 'Distance (km)',
        data: [],
        borderColor: '#00ff9d',
        backgroundColor: 'rgba(0, 255, 157, 0.1)',
        fill: true,
        tension: 0.4
      }]
    },
    options: chartOptions
  });
  
  // Battery vs Time Chart
  var batteryCtx = document.getElementById('batteryChart').getContext('2d');
  batteryChart = new Chart(batteryCtx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: 'Battery (%)',
        data: [],
        borderColor: '#ffb300',
        backgroundColor: 'rgba(255, 179, 0, 0.1)',
        fill: true,
        tension: 0.4
      }]
    },
    options: chartOptions
  });
}

function updateCharts() {
  var now = new Date();
  var timeLabel = now.toLocaleTimeString();
  
  // Collect data from all devices
  var avgSpeed = 0, speedCount = 0;
  var totalDistance = 0;
  var avgBattery = 0, batteryCount = 0;
  
  var devEntries = Object.entries(devices);
  for (var i = 0; i < devEntries.length; i++) {
    var dev = devEntries[i][1];
    if (dev.avgSpeed !== undefined) {
      avgSpeed += dev.avgSpeed;
      speedCount++;
    }
    
    totalDistance += computeDistanceFromPoints(dev.points || []);
    
    var batt = getBatteryFromDeviceData(dev.data || {});
    if (batt.pct !== null) {
      avgBattery += batt.pct;
      batteryCount++;
    }
  }
  
  if (speedCount > 0) avgSpeed /= speedCount;
  if (batteryCount > 0) avgBattery /= batteryCount;
  
  // Update Speed Chart
  if (speedChart.data.labels.length > 20) {
    speedChart.data.labels.shift();
    speedChart.data.datasets[0].data.shift();
  }
  speedChart.data.labels.push(timeLabel);
  speedChart.data.datasets[0].data.push(avgSpeed);
  speedChart.update('none');
  
  // Update Distance Chart
  if (distanceChart.data.labels.length > 20) {
    distanceChart.data.labels.shift();
    distanceChart.data.datasets[0].data.shift();
  }
  distanceChart.data.labels.push(timeLabel);
  distanceChart.data.datasets[0].data.push(totalDistance);
  distanceChart.update('none');
  
  // Update Battery Chart
  if (batteryChart.data.labels.length > 20) {
    batteryChart.data.labels.shift();
    batteryChart.data.datasets[0].data.shift();
  }
  batteryChart.data.labels.push(timeLabel);
  batteryChart.data.datasets[0].data.push(avgBattery);
  batteryChart.update('none');
}

// ============ FIREBASE LISTENERS ============

// Devices listener
db.ref('devices').on('value', function(snapshot) {
  var all = snapshot.val() || {};
  var now = Date.now();
  
  var normalized = {};
  for (var name in all) {
    var node = all[name];
    if (!node) continue;
    
    var flat = coerceCoord(node);
    if (flat) {
      var latestTime = parseLastUpdateMs(flat.t || flat.timestamp) || now;
      normalized[name] = { latest: flat, points: [{ lat: flat.lat, lng: flat.lng, time: latestTime }] };
      continue;
    }
    
    var children = Object.values(node)
      .map(function(p, idx) {
        var c = coerceCoord(p);
        return c ? { lat: c.lat, lng: c.lng, t: c.t, timestamp: c.timestamp, _sort: coordSortValue(c, idx) } : null;
      })
      .filter(Boolean)
      .sort(function(a, b) { return a._sort - b._sort; });
    
    if (children.length === 0) continue;
    
    var latest = children[children.length - 1];
    var points = children.map(function(p) { return { lat: p.lat, lng: p.lng, time: parseLastUpdateMs(p.t || p.timestamp) || now }; });
    normalized[name] = { latest: latest, points: points };
  }
  
  // Update devices
  for (var name in normalized) {
    var latest = normalized[name].latest;
    if (!latest || typeof latest.lat !== 'number' || typeof latest.lng !== 'number') continue;
    
    var latestTime = parseLastUpdateMs(latest.t || latest.timestamp || latest.time) || now;
    var speedVal = toNumber(latest.spd || latest.speed);

    if (!devices[name]) {
      devices[name] = {
        lastSeen: latestTime,
        data: latest,
        points: normalized[name].points,
        speedHistory: speedVal !== null ? [speedVal] : []
      };
    } else {
      devices[name].lastSeen = latestTime;
      devices[name].data = latest;
      devices[name].points = normalized[name].points;
      if (!devices[name].speedHistory) devices[name].speedHistory = [];
    }

    if (speedVal !== null) {
      devices[name].speedHistory.push(speedVal);
      if (devices[name].speedHistory.length > MAX_SPEED_SAMPLES) {
        devices[name].speedHistory.shift();
      }
    }
  }
  
  // derive speed stats
  for (var devName in devices) {
    var hist = devices[devName].speedHistory || [];
    if (hist.length > 0) {
      var total = hist.reduce(function(a,b){ return a + b; }, 0);
      devices[devName].avgSpeed = total / hist.length;
      devices[devName].maxSpeed = Math.max.apply(Math, hist);
    } else {
      devices[devName].avgSpeed = 0;
      devices[devName].maxSpeed = 0;
    }
  }

  // Remove old devices
  for (var name in devices) {
    if (!normalized[name]) {
      delete devices[name];
    }
  }
  
  // Update UI
  updateAllSections();
});

// Routes listener
db.ref('routes').on('child_added', function(deviceSnap) {
  var deviceId = deviceSnap.key;
  if (!routesCache[deviceId]) {
    routesCache[deviceId] = { checkpoints: {} };
    
    var cpsRef = db.ref('routes/' + deviceId + '/default/checkpoints');
    cpsRef.once('value', function(s) {
      var val = s.val() || {};
      routesCache[deviceId].checkpoints = val;
      for (var cpId in val) {
        var cp = val[cpId];
        if (cp && (cp.completed || cp.verified)) {
          completedCheckpoints.add(deviceId + '_' + cpId);
        }
      }
      updateAllSections();
    });
    
    cpsRef.on('child_added', function(cpSnap) {
      var cp = cpSnap.val();
      routesCache[deviceId].checkpoints[cpSnap.key] = cp;
      if (cp && (cp.completed || cp.verified)) {
        completedCheckpoints.add(deviceId + '_' + cpSnap.key);
      }
      updateAllSections();
    });

    cpsRef.on('child_changed', function(cpSnap) {
      var cp = cpSnap.val();
      routesCache[deviceId].checkpoints[cpSnap.key] = cp;
      if (cp && (cp.completed || cp.verified)) {
        completedCheckpoints.add(deviceId + '_' + cpSnap.key);
      }
      updateAllSections();
    });
  }
});

// Exercises listener
db.ref('exercises').on('child_added', function(snap) {
  var exercise = snap.val();
  if (exercise && exercise.id) {
    exercisesCache[exercise.id] = exercise;
    populateExerciseSelect();
    updateAllSections();
  }
});

db.ref('exercises').on('child_changed', function(snap) {
  var exercise = snap.val();
  if (exercise && exercise.id) {
    exercisesCache[exercise.id] = exercise;
    populateExerciseSelect();
    updateAllSections();
  }
});

db.ref('exercises').on('child_removed', function(snap) {
  var exercise = snap.val();
  if (exercise && exercise.id) {
    delete exercisesCache[exercise.id];
    populateExerciseSelect();
    updateAllSections();
  }
});

function populateExerciseSelect() {
  var select = document.getElementById('exerciseSelect');
  if (!select) return;
  
  var exercises = getExerciseStore();
  var html = '<option value="">Select Exercise</option>';
  for (var i = 0; i < exercises.length; i++) {
    var item = exercises[i];
    html += '<option value="' + item.id + '">' + (item.name || 'Untitled') + ' (' + (item.date || '--') + ')</option>';
  }
  select.innerHTML = html;
  autoSelectExercise();
}

// ============ MAIN UPDATE FUNCTION ============
function updateAllSections() {
  renderExerciseSummary();
  renderDevicePerformanceTable();
  renderDeviceActivity();
  renderExerciseTimeline();
  renderPerformanceMetrics();
  autoSelectExercise();
}

// ============ INITIALIZATION ============
document.addEventListener('DOMContentLoaded', function() {
  // Hide loading
  var loading = document.getElementById('loading');
  if (loading) loading.style.display = 'none';
  
  // Initialize charts
  initCharts();
  
  // Populate exercise select
  populateExerciseSelect();
  
  // Initial render
  updateAllSections();
  
  // Update charts every 5 seconds
  setInterval(updateCharts, 5000);
  
  // Update refresh indicator
  setInterval(function() {
    var indicator = document.getElementById('refreshIndicator');
    if (indicator) {
      indicator.innerHTML = '<span class="refresh-dot"></span> Live';
    }
  }, 1000);

  // Sidebar navigation
  var navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(function(btn) {
    btn.addEventListener('click', function() {
      var target = btn.getAttribute('data-target');
      document.querySelectorAll('.nav-item').forEach(function(b){ b.classList.remove('active'); });
      btn.classList.add('active');
      document.querySelectorAll('.panel').forEach(function(p){ p.classList.remove('active'); });
      var panel = document.getElementById(target);
      if (panel) panel.classList.add('active');
    });
  });

  // Fullscreen toggle
  var fsBtn = document.getElementById('fullscreenBtn');
  if (fsBtn) {
    fsBtn.addEventListener('click', function() {
      var elem = document.documentElement;
      if (!document.fullscreenElement) {
        elem.requestFullscreen().catch(function(err){ console.warn('Fullscreen failed', err); });
      } else {
        document.exitFullscreen().catch(function(err){ console.warn('Exit fullscreen failed', err); });
      }
    });
  }
  document.addEventListener('fullscreenchange', function() {
    document.body.classList.toggle('fullscreen-mode', Boolean(document.fullscreenElement));
  });
});

// Export for use in HTML
window.getSelectedExercise = getSelectedExercise;

